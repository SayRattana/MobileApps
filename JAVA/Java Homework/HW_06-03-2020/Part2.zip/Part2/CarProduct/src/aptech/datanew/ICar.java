package aptech.datanew;

/**
 *
 * @author Say Rattana
 */
public interface ICar {
    public void input();
    public void show();
}
