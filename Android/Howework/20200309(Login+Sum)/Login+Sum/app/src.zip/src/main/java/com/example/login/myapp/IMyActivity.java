package com.example.login.myapp;

public interface IMyActivity {
    public void mapUIToProperties();
    public void setUpAction();
}
