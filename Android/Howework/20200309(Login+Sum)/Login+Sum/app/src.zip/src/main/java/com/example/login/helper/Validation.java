package com.example.login.helper;

public class Validation {
    public  static  ValidationError validateUsername(String username){
        if(username.length()<2){
            return ValidationError.USER_ERROR;
        }else{
            return null; //No error
        }
    }

    public static ValidationError validatePassword(String password){
        if(password.length() < 2) {
            return ValidationError.PASSWORD_ERROR;
        } else {
            return null;//No error
        }
    }

}
